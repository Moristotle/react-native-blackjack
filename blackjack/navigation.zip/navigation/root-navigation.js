import {createAppContainer} from 'react-navigation';
import {createStackNavigator} from 'react-navigation-stack'
import Profile from '../Profile/screens/Profile';
import Home from '../Home/screens/Home';


const MainNavigator = createStackNavigator({
    
    /*login :{
        screen: Login,
        navigationOptions: () => ({
            title: 'Login'
        })
    },*/
    home :{
        screen: Home,
        navigationOptions: () => ({
            title: 'Home'
        })
    },
    profile:{
        screen: Profile,
        navigationOptions: () => ({
            title: 'Profile'
        })
    }
    /*,
    game :{
        screen: Game,
        navigationOptions: () => ({
            title: 'Game'
        })
    },*/
    
})
const Rootnavigation = createAppContainer(MainNavigator);
export default Rootnavigation;
